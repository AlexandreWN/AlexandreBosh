#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a = 0, b = 0, c = 0;
    int *ab = &a;
    int *bc = &b;
    int *cd = &c;

    printf("Digite o numero1: ");
    scanf("%d",ab);

    printf("Digite o numero2: ");
    scanf("%d",bc);

    printf("Digite o numero3: ");
    scanf("%d",cd);

    printf("numero1: %d\n",*ab);
    printf("numero2: %d\n",*bc);
    printf("numero3: %d\n",*cd);

}
